'use strict'
;(() => {
  var V = Object.create
  var R = Object.defineProperty
  var G = Object.getOwnPropertyDescriptor
  var Z = Object.getOwnPropertyNames
  var z = Object.getPrototypeOf,
    H = Object.prototype.hasOwnProperty
  var K = (i, s) => () => (s || i((s = { exports: {} }).exports, s), s.exports)
  var J = (i, s, a, o) => {
    if ((s && typeof s == 'object') || typeof s == 'function')
      for (let c of Z(s))
        !H.call(i, c) &&
          c !== a &&
          R(i, c, { get: () => s[c], enumerable: !(o = G(s, c)) || o.enumerable })
    return i
  }
  var M = (i, s, a) => (
    (a = i != null ? V(z(i)) : {}),
    J(s || !i || !i.__esModule ? R(a, 'default', { value: i, enumerable: !0 }) : a, i)
  )
  var v = K((T, D) => {
    ;(function (i, s) {
      if (typeof define == 'function' && define.amd) define('webextension-polyfill', ['module'], s)
      else if (typeof T < 'u') s(D)
      else {
        var a = { exports: {} }
        s(a), (i.browser = a.exports)
      }
    })(typeof globalThis < 'u' ? globalThis : typeof self < 'u' ? self : T, function (i) {
      'use strict'
      if (!globalThis.chrome?.runtime?.id)
        throw new Error('This script should only be loaded in a browser extension.')
      if (
        typeof globalThis.browser > 'u' ||
        Object.getPrototypeOf(globalThis.browser) !== Object.prototype
      ) {
        let s = 'The message port closed before a response was received.',
          a = (o) => {
            let c = {
              alarms: {
                clear: { minArgs: 0, maxArgs: 1 },
                clearAll: { minArgs: 0, maxArgs: 0 },
                get: { minArgs: 0, maxArgs: 1 },
                getAll: { minArgs: 0, maxArgs: 0 },
              },
              bookmarks: {
                create: { minArgs: 1, maxArgs: 1 },
                get: { minArgs: 1, maxArgs: 1 },
                getChildren: { minArgs: 1, maxArgs: 1 },
                getRecent: { minArgs: 1, maxArgs: 1 },
                getSubTree: { minArgs: 1, maxArgs: 1 },
                getTree: { minArgs: 0, maxArgs: 0 },
                move: { minArgs: 2, maxArgs: 2 },
                remove: { minArgs: 1, maxArgs: 1 },
                removeTree: { minArgs: 1, maxArgs: 1 },
                search: { minArgs: 1, maxArgs: 1 },
                update: { minArgs: 2, maxArgs: 2 },
              },
              browserAction: {
                disable: { minArgs: 0, maxArgs: 1, fallbackToNoCallback: !0 },
                enable: { minArgs: 0, maxArgs: 1, fallbackToNoCallback: !0 },
                getBadgeBackgroundColor: { minArgs: 1, maxArgs: 1 },
                getBadgeText: { minArgs: 1, maxArgs: 1 },
                getPopup: { minArgs: 1, maxArgs: 1 },
                getTitle: { minArgs: 1, maxArgs: 1 },
                openPopup: { minArgs: 0, maxArgs: 0 },
                setBadgeBackgroundColor: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setBadgeText: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setIcon: { minArgs: 1, maxArgs: 1 },
                setPopup: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setTitle: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
              },
              browsingData: {
                remove: { minArgs: 2, maxArgs: 2 },
                removeCache: { minArgs: 1, maxArgs: 1 },
                removeCookies: { minArgs: 1, maxArgs: 1 },
                removeDownloads: { minArgs: 1, maxArgs: 1 },
                removeFormData: { minArgs: 1, maxArgs: 1 },
                removeHistory: { minArgs: 1, maxArgs: 1 },
                removeLocalStorage: { minArgs: 1, maxArgs: 1 },
                removePasswords: { minArgs: 1, maxArgs: 1 },
                removePluginData: { minArgs: 1, maxArgs: 1 },
                settings: { minArgs: 0, maxArgs: 0 },
              },
              commands: { getAll: { minArgs: 0, maxArgs: 0 } },
              contextMenus: {
                remove: { minArgs: 1, maxArgs: 1 },
                removeAll: { minArgs: 0, maxArgs: 0 },
                update: { minArgs: 2, maxArgs: 2 },
              },
              cookies: {
                get: { minArgs: 1, maxArgs: 1 },
                getAll: { minArgs: 1, maxArgs: 1 },
                getAllCookieStores: { minArgs: 0, maxArgs: 0 },
                remove: { minArgs: 1, maxArgs: 1 },
                set: { minArgs: 1, maxArgs: 1 },
              },
              devtools: {
                inspectedWindow: { eval: { minArgs: 1, maxArgs: 2, singleCallbackArg: !1 } },
                panels: {
                  create: { minArgs: 3, maxArgs: 3, singleCallbackArg: !0 },
                  elements: { createSidebarPane: { minArgs: 1, maxArgs: 1 } },
                },
              },
              downloads: {
                cancel: { minArgs: 1, maxArgs: 1 },
                download: { minArgs: 1, maxArgs: 1 },
                erase: { minArgs: 1, maxArgs: 1 },
                getFileIcon: { minArgs: 1, maxArgs: 2 },
                open: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                pause: { minArgs: 1, maxArgs: 1 },
                removeFile: { minArgs: 1, maxArgs: 1 },
                resume: { minArgs: 1, maxArgs: 1 },
                search: { minArgs: 1, maxArgs: 1 },
                show: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
              },
              extension: {
                isAllowedFileSchemeAccess: { minArgs: 0, maxArgs: 0 },
                isAllowedIncognitoAccess: { minArgs: 0, maxArgs: 0 },
              },
              history: {
                addUrl: { minArgs: 1, maxArgs: 1 },
                deleteAll: { minArgs: 0, maxArgs: 0 },
                deleteRange: { minArgs: 1, maxArgs: 1 },
                deleteUrl: { minArgs: 1, maxArgs: 1 },
                getVisits: { minArgs: 1, maxArgs: 1 },
                search: { minArgs: 1, maxArgs: 1 },
              },
              i18n: {
                detectLanguage: { minArgs: 1, maxArgs: 1 },
                getAcceptLanguages: { minArgs: 0, maxArgs: 0 },
              },
              identity: { launchWebAuthFlow: { minArgs: 1, maxArgs: 1 } },
              idle: { queryState: { minArgs: 1, maxArgs: 1 } },
              management: {
                get: { minArgs: 1, maxArgs: 1 },
                getAll: { minArgs: 0, maxArgs: 0 },
                getSelf: { minArgs: 0, maxArgs: 0 },
                setEnabled: { minArgs: 2, maxArgs: 2 },
                uninstallSelf: { minArgs: 0, maxArgs: 1 },
              },
              notifications: {
                clear: { minArgs: 1, maxArgs: 1 },
                create: { minArgs: 1, maxArgs: 2 },
                getAll: { minArgs: 0, maxArgs: 0 },
                getPermissionLevel: { minArgs: 0, maxArgs: 0 },
                update: { minArgs: 2, maxArgs: 2 },
              },
              pageAction: {
                getPopup: { minArgs: 1, maxArgs: 1 },
                getTitle: { minArgs: 1, maxArgs: 1 },
                hide: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setIcon: { minArgs: 1, maxArgs: 1 },
                setPopup: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setTitle: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                show: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
              },
              permissions: {
                contains: { minArgs: 1, maxArgs: 1 },
                getAll: { minArgs: 0, maxArgs: 0 },
                remove: { minArgs: 1, maxArgs: 1 },
                request: { minArgs: 1, maxArgs: 1 },
              },
              runtime: {
                getBackgroundPage: { minArgs: 0, maxArgs: 0 },
                getPlatformInfo: { minArgs: 0, maxArgs: 0 },
                openOptionsPage: { minArgs: 0, maxArgs: 0 },
                requestUpdateCheck: { minArgs: 0, maxArgs: 0 },
                sendMessage: { minArgs: 1, maxArgs: 3 },
                sendNativeMessage: { minArgs: 2, maxArgs: 2 },
                setUninstallURL: { minArgs: 1, maxArgs: 1 },
              },
              sessions: {
                getDevices: { minArgs: 0, maxArgs: 1 },
                getRecentlyClosed: { minArgs: 0, maxArgs: 1 },
                restore: { minArgs: 0, maxArgs: 1 },
              },
              storage: {
                local: {
                  clear: { minArgs: 0, maxArgs: 0 },
                  get: { minArgs: 0, maxArgs: 1 },
                  getBytesInUse: { minArgs: 0, maxArgs: 1 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  set: { minArgs: 1, maxArgs: 1 },
                },
                managed: {
                  get: { minArgs: 0, maxArgs: 1 },
                  getBytesInUse: { minArgs: 0, maxArgs: 1 },
                },
                sync: {
                  clear: { minArgs: 0, maxArgs: 0 },
                  get: { minArgs: 0, maxArgs: 1 },
                  getBytesInUse: { minArgs: 0, maxArgs: 1 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  set: { minArgs: 1, maxArgs: 1 },
                },
              },
              tabs: {
                captureVisibleTab: { minArgs: 0, maxArgs: 2 },
                create: { minArgs: 1, maxArgs: 1 },
                detectLanguage: { minArgs: 0, maxArgs: 1 },
                discard: { minArgs: 0, maxArgs: 1 },
                duplicate: { minArgs: 1, maxArgs: 1 },
                executeScript: { minArgs: 1, maxArgs: 2 },
                get: { minArgs: 1, maxArgs: 1 },
                getCurrent: { minArgs: 0, maxArgs: 0 },
                getZoom: { minArgs: 0, maxArgs: 1 },
                getZoomSettings: { minArgs: 0, maxArgs: 1 },
                goBack: { minArgs: 0, maxArgs: 1 },
                goForward: { minArgs: 0, maxArgs: 1 },
                highlight: { minArgs: 1, maxArgs: 1 },
                insertCSS: { minArgs: 1, maxArgs: 2 },
                move: { minArgs: 2, maxArgs: 2 },
                query: { minArgs: 1, maxArgs: 1 },
                reload: { minArgs: 0, maxArgs: 2 },
                remove: { minArgs: 1, maxArgs: 1 },
                removeCSS: { minArgs: 1, maxArgs: 2 },
                sendMessage: { minArgs: 2, maxArgs: 3 },
                setZoom: { minArgs: 1, maxArgs: 2 },
                setZoomSettings: { minArgs: 1, maxArgs: 2 },
                update: { minArgs: 1, maxArgs: 2 },
              },
              topSites: { get: { minArgs: 0, maxArgs: 0 } },
              webNavigation: {
                getAllFrames: { minArgs: 1, maxArgs: 1 },
                getFrame: { minArgs: 1, maxArgs: 1 },
              },
              webRequest: { handlerBehaviorChanged: { minArgs: 0, maxArgs: 0 } },
              windows: {
                create: { minArgs: 0, maxArgs: 1 },
                get: { minArgs: 1, maxArgs: 2 },
                getAll: { minArgs: 0, maxArgs: 1 },
                getCurrent: { minArgs: 0, maxArgs: 1 },
                getLastFocused: { minArgs: 0, maxArgs: 1 },
                remove: { minArgs: 1, maxArgs: 1 },
                update: { minArgs: 2, maxArgs: 2 },
              },
            }
            if (Object.keys(c).length === 0)
              throw new Error('api-metadata.json has not been included in browser-polyfill')
            class P extends WeakMap {
              constructor(r, t = void 0) {
                super(t), (this.createItem = r)
              }
              get(r) {
                return this.has(r) || this.set(r, this.createItem(r)), super.get(r)
              }
            }
            let U = (e) => e && typeof e == 'object' && typeof e.then == 'function',
              S =
                (e, r) =>
                (...t) => {
                  o.runtime.lastError
                    ? e.reject(new Error(o.runtime.lastError.message))
                    : r.singleCallbackArg || (t.length <= 1 && r.singleCallbackArg !== !1)
                      ? e.resolve(t[0])
                      : e.resolve(t)
                },
              p = (e) => (e == 1 ? 'argument' : 'arguments'),
              _ = (e, r) =>
                function (g, ...A) {
                  if (A.length < r.minArgs)
                    throw new Error(
                      `Expected at least ${r.minArgs} ${p(r.minArgs)} for ${e}(), got ${A.length}`,
                    )
                  if (A.length > r.maxArgs)
                    throw new Error(
                      `Expected at most ${r.maxArgs} ${p(r.maxArgs)} for ${e}(), got ${A.length}`,
                    )
                  return new Promise((l, u) => {
                    if (r.fallbackToNoCallback)
                      try {
                        g[e](...A, S({ resolve: l, reject: u }, r))
                      } catch {
                        g[e](...A), (r.fallbackToNoCallback = !1), (r.noCallback = !0), l()
                      }
                    else
                      r.noCallback ? (g[e](...A), l()) : g[e](...A, S({ resolve: l, reject: u }, r))
                  })
                },
              F = (e, r, t) =>
                new Proxy(r, {
                  apply(g, A, l) {
                    return t.call(A, e, ...l)
                  },
                }),
              b = Function.call.bind(Object.prototype.hasOwnProperty),
              k = (e, r = {}, t = {}) => {
                let g = Object.create(null),
                  A = {
                    has(u, n) {
                      return n in e || n in g
                    },
                    get(u, n, x) {
                      if (n in g) return g[n]
                      if (!(n in e)) return
                      let m = e[n]
                      if (typeof m == 'function')
                        if (typeof r[n] == 'function') m = F(e, e[n], r[n])
                        else if (b(t, n)) {
                          let d = _(n, t[n])
                          m = F(e, e[n], d)
                        } else m = m.bind(e)
                      else if (typeof m == 'object' && m !== null && (b(r, n) || b(t, n)))
                        m = k(m, r[n], t[n])
                      else if (b(t, '*')) m = k(m, r[n], t['*'])
                      else
                        return (
                          Object.defineProperty(g, n, {
                            configurable: !0,
                            enumerable: !0,
                            get() {
                              return e[n]
                            },
                            set(d) {
                              e[n] = d
                            },
                          }),
                          m
                        )
                      return (g[n] = m), m
                    },
                    set(u, n, x, m) {
                      return n in g ? (g[n] = x) : (e[n] = x), !0
                    },
                    defineProperty(u, n, x) {
                      return Reflect.defineProperty(g, n, x)
                    },
                    deleteProperty(u, n) {
                      return Reflect.deleteProperty(g, n)
                    },
                  },
                  l = Object.create(e)
                return new Proxy(l, A)
              },
              w = (e) => ({
                addListener(r, t, ...g) {
                  r.addListener(e.get(t), ...g)
                },
                hasListener(r, t) {
                  return r.hasListener(e.get(t))
                },
                removeListener(r, t) {
                  r.removeListener(e.get(t))
                },
              }),
              W = new P((e) =>
                typeof e != 'function'
                  ? e
                  : function (t) {
                      let g = k(t, {}, { getContent: { minArgs: 0, maxArgs: 0 } })
                      e(g)
                    },
              ),
              B = new P((e) =>
                typeof e != 'function'
                  ? e
                  : function (t, g, A) {
                      let l = !1,
                        u,
                        n = new Promise((h) => {
                          u = function (f) {
                            ;(l = !0), h(f)
                          }
                        }),
                        x
                      try {
                        x = e(t, g, u)
                      } catch (h) {
                        x = Promise.reject(h)
                      }
                      let m = x !== !0 && U(x)
                      if (x !== !0 && !m && !l) return !1
                      let d = (h) => {
                        h.then(
                          (f) => {
                            A(f)
                          },
                          (f) => {
                            let E
                            f && (f instanceof Error || typeof f.message == 'string')
                              ? (E = f.message)
                              : (E = 'An unexpected error occurred'),
                              A({ __mozWebExtensionPolyfillReject__: !0, message: E })
                          },
                        ).catch((f) => {})
                      }
                      return d(m ? x : n), !0
                    },
              ),
              q = ({ reject: e, resolve: r }, t) => {
                o.runtime.lastError
                  ? o.runtime.lastError.message === s
                    ? r()
                    : e(new Error(o.runtime.lastError.message))
                  : t && t.__mozWebExtensionPolyfillReject__
                    ? e(new Error(t.message))
                    : r(t)
              },
              N = (e, r, t, ...g) => {
                if (g.length < r.minArgs)
                  throw new Error(
                    `Expected at least ${r.minArgs} ${p(r.minArgs)} for ${e}(), got ${g.length}`,
                  )
                if (g.length > r.maxArgs)
                  throw new Error(
                    `Expected at most ${r.maxArgs} ${p(r.maxArgs)} for ${e}(), got ${g.length}`,
                  )
                return new Promise((A, l) => {
                  let u = q.bind(null, { resolve: A, reject: l })
                  g.push(u), t.sendMessage(...g)
                })
              },
              I = {
                devtools: { network: { onRequestFinished: w(W) } },
                runtime: {
                  onMessage: w(B),
                  onMessageExternal: w(B),
                  sendMessage: N.bind(null, 'sendMessage', { minArgs: 1, maxArgs: 3 }),
                },
                tabs: { sendMessage: N.bind(null, 'sendMessage', { minArgs: 2, maxArgs: 3 }) },
              },
              C = {
                clear: { minArgs: 1, maxArgs: 1 },
                get: { minArgs: 1, maxArgs: 1 },
                set: { minArgs: 1, maxArgs: 1 },
              }
            return (
              (c.privacy = { network: { '*': C }, services: { '*': C }, websites: { '*': C } }),
              k(o, I, c)
            )
          }
        i.exports = a(chrome)
      } else i.exports = globalThis.browser
    })
  })
  var O = M(v())
  var L = M(v()),
    j = {
      'chatgpt-paid': {
        callbackName: 'useArkoseSetupEnforcementPaid',
        keyValue: '35536E1E-65B4-4D96-9D97-6ADB7EFF8147',
      },
      'chatgpt-freeaccount': {
        callbackName: 'useArkoseSetupEnforcementFreeAccount',
        keyValue: '3D86FBBA-9D22-402A-B512-3420086BA6CC',
      },
      'chatgpt-noauth': {
        callbackName: 'useArkoseSetupEnforcementNoAuth',
        keyValue: 'BD7D7B66-1476-42B2-A6BE-095F3BB4DF2D',
      },
      'chatgpt-subscription': {
        callbackName: 'useArkoseSetupEnforcementSubscription',
        keyValue: '8E3CED7F-F5EA-43D0-A5C3-745D29FDCFBC',
      },
    },
    y = class {
      constructor(s) {
        this.enforcementResolve = null
        ;(this.enforcement = void 0),
          (this.pendingPromises = []),
          (this.userType = s),
          (window[j[s].callbackName] = this.useArkoseSetupEnforcement.bind(this)),
          (this.enforcementPromise = new Promise((a) => {
            this.enforcementResolve = a
          })),
          this.injectScript()
      }
      useArkoseSetupEnforcement(s) {
        ;(this.enforcement = s),
          s.setConfig({
            onCompleted: (a) => {
              this.pendingPromises.forEach((o) => {
                o.resolve(a.token)
              }),
                (this.pendingPromises = [])
            },
            onReady: () => {
              this.enforcementResolve?.(), (this.enforcementResolve = null)
            },
            onError: (a) => {},
            onFailed: (a) => {
              this.pendingPromises.forEach((o) => {
                o.reject(new Error('Failed to generate arkose token'))
              })
            },
          })
      }
      injectScript() {
        let s = document.createElement('script'),
          a = j[this.userType]
        ;(s.src = L.default.runtime.getURL('js/v2/' + a.keyValue + '/api.js')),
          (s.async = !0),
          (s.defer = !0),
          s.setAttribute('data-callback', a.callbackName),
          document.body.appendChild(s)
      }
      async generate(s) {
        let a = !1,
          o = setTimeout(() => {
            a = !0
          }, 1e4)
        try {
          await this.enforcementPromise
        } catch {
          throw new Error('Failed to generate arkose token')
        }
        if ((clearTimeout(o), a)) throw new Error('Generate arkose token timeout')
        return new Promise((c) => {
          this.enforcement.setConfig({ data: { blob: s } }),
            (this.pendingPromises = [{ resolve: c }]),
            this.enforcement.run()
        })
      }
    }
  var $ = {}
  async function Q(i, s) {
    let a = new y(i)
    $[i] || ($[i] = a)
    let o = await a.generate(s)
    return o || null
  }
  O.default.runtime.onMessage.addListener((i) => {
    if (i.type === 'getArkoseTokenSidepanel') return Q(i.userType, i.dx).then((s) => s)
  })

  async function getToken(persona, dx) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        Q(persona, dx)
          .then((res) => {
            console.log('🚀 ~ .then ~ res:', res)
            resolve(res)
          })
          .catch((err) => {
            reject(err)
          })
      }, 0.1 * 1000)
    })
  }

  var port = O.default.runtime.connect({ name: 'getArkoseToken' })

  port.onMessage.addListener(async (msg) => {
    console.log('🚀 ~ port.onMessage.addListener ~ msg:', msg)
    const { type, persona, dx } = msg

    if (type === 'get') {
      try {
        const result = await getToken(persona, dx)
        port.postMessage({ status: 'success', type: 'token', token: result })
      } catch (error) {
        port.postMessage({ status: 'error', type: 'token', token: error })
      }
    }

    return true
  })
})()
